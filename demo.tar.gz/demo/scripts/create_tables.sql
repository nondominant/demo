CREATE TABLE IF NOT EXISTS collars (
	id varchar(50) NOT NULL,
	collarStatus varchar(20) NOT NULL,
	PRIMARY KEY (id)
);
CREATE TABLE IF NOT EXISTS cows (
	id varchar(50) NOT NULL,
	cowNumber INT NOT NULL,
	collar varchar(50),
	PRIMARY KEY (id),
	CONSTRAINT fk_collar 
		FOREIGN KEY(collar) 
		REFERENCES collars(id)
);
