import json
import requests

def post_event(url, data):
    x = requests.post(url, json = data)
    print(x)

def put_event(url, data):
    x = requests.put(url, json = data)
    print(x)

def get_event(url, data):
    x = requests.get(url)
    print(x)


body = [
        {'url' : 'http://localhost:80/cows', 'data' : {'collarId':'6','cowNumber':'101'}},
        {'url' : 'http://localhost:80/cows', 'data' : {'collarId':'5','cowNumber':'102'}},
        {'url' : 'http://localhost:80/cows', 'data' : {'collarId':'1','cowNumber':'103'}},
        {'url' : 'http://localhost:80/cows', 'data' : {'collarId':'2','cowNumber':'104'}},
        {'url' : 'http://localhost:80/cows', 'data' : {'collarId':'3','cowNumber':'105'}},
        {'url' : 'http://localhost:80/cows', 'data' : {'collarId':'4','cowNumber':'106'}},
        ]

for d in body:
    post_event(d['url'], d['data'])
