
## Nodejs-Express server, Postgres for persistence, Redis for caching

Included in the project is a `frontend` service and an `nginx` service to 
facilitate demonstration of the functionality


## Quick start
rebuild containers
```
$docker-compose build
```
start services
```
$docker-compose up -d
```
navigate to ./scripts/ and run
```
$python init.py
```
navigate to http://localhost:5000

## Without python installed
if you do not have python installed:
start services
```
$docker-compose up -d
```
>navigate to http://localhost:5000
>manually add entries using the POST request demo
Note: collar number must be between 1-50


## Compose file

```
[_compose.yaml_](compose.yaml)
```
```
services:
        postgres:
                image: postgres:11
                restart: always
                ports:
                        - '5432'
                env_file:
                        - postgres.env
                healthcheck:
                        test: ["CMD-SHELL", "pg_isready"]
                        interval: 10s
                        timeout: 5s
                        retries: 5
                volumes: 
                        - ./scripts/create_tables.sql:/docker-entrypoint-initdb.d/create_tables.sql
        redis:
                restart: on-failure
                image: 'redislabs/redismod'
                ports:
                        - '6379'
        server1:
                restart: on-failure
                build: ./backend_server
                hostname: backend1
                ports:
                        - '5000'
                env_file:
                        - backend.env
                depends_on:
                        postgres:
                                condition: service_healthy
        server2:
                restart: on-failure
                build: ./backend_server
                hostname: backend2
                ports:
                        - '5000'
                env_file:
                        - backend.env
                depends_on:
                        postgres:
                                condition: service_healthy
        frontend:
                restart: on-failure
                build: ./frontend
                hostname: frontend
                ports:
                        - '5000:5000'
        nginx:
                restart: on-failure
                build: ./nginx
                ports:
                        - '80:80'
                depends_on:
                        - server1
                        - server2
volumes:
        scripts:

```
The compose file defines an application with the following services `redis`, `nginx`, `server1` and `server2`, `frontend`, `postgres`.
When deploying the application, docker compose maps port 80 of the nginx service container to port 80 of the host as specified in the file.


## Deploy with docker compose

```
$ docker-compose up -d
```

## Expected result

Listing containers must show 6 containers running and the port mapping as below:
```
docker ps
```

## Testing the app

After the application starts, navigate to `http://localhost:5000` in your web browser


## Stop and remove the containers

```
$ docker compose down
```

## Further Features

The only logging is the default output of docker-compose to stdout.
server1 and server2 currently redirect stout and stderr to a file inside their respective containers,
this is only acceptable for debugging purposes.
>implement logging

Their are no automated tests
>implement automated testing

Redis does not have a password
>implement authenication on redis

All containers remain running as root
>implement priviledge de-escalation

Postgres and Redis queries and currently implemented in series, but 
it is possible to refactor them so that they run in parallel and
then Promise.all is used to await them both before returning.
This would greatly improve response times.

