// When using this table component always ensure that the model has a unique (primary) key
// that can be used as a row id. The getRowId function will return the first entry in the array
// given by Object.values(params.data), so it is important to ensure your table is structured such
// that the first column is the primary key.

export function generateTable(selector, model, urlInsert, urlRead, urlDelete) {
let hooks = {
	refresh: () => {
		console.log('refresh');
		fetch(urlRead, {
			method: 'GET', // or 'PUT'
			headers: {
			'Content-Type': 'application/json',
			'Cache-Control': 'no-cache',
			},
		})
		.then((response) => response.json())
		.then((data) => {
			console.log('response data', data);
			setRowData(data);
		})
		.catch((error) => {
			console.log(error);
		});
	},
	clear: () => {
		setRowData([{}]);
	}
}


var columnDefs = [...model];
let rowData = [];
let inputRow = {};

function setRowData(newData) {
rowData = newData;
gridOptions.api.setRowData(rowData);
}

function setInputRow(newData) {
inputRow = newData;
}


const gridOptions = {
  rowData: null,
  columnDefs: columnDefs,
  defaultColDef: {
    flex: 1,
    editable: false,
  },
  getRowId: (params) => {
	  // returns the data in the first column, 
	  // this should always be the primary key
    return Object.values(params.data)[0];
  },
};

	// lookup the container we want the Grid to use
	var eGridDiv = document.querySelector(selector);

	// create the grid passing in the div to use together with the columns &amp; data we want to use
	new agGrid.Grid(eGridDiv, gridOptions);
	fetch(urlRead, {
		method: 'GET', // or 'PUT'
		headers: {
		'Content-Type': 'application/json',
		'Cache-Control': 'no-cache',
		},
	})
	.then((response) => response.json())
	.then((data) => {
		setRowData(data);
	})
	.catch((error) => {
		console.log(error);
	});

	return hooks;
};

