async function test(collarId) {
await fetch(`https://5d96585ca824b400141d26b2.mockapi.io/halter/device/${collarId}/status`, {
	method: 'GET',
	headers: {
		'Content-Type':'application/json',
		'Cache-Control':'no-cache',
	},
})
.then((data) => data.json())
.then(async (response) => {
	console.log(response)
	// if multiple, iterate and find latest
	if (Array.isArray(response) && response.length > 1) {
		let latest = response[0]; 
		for (let i = 1; i < response.length; i++) {
			console.log('response[i].timestamp', response[i].timestamp);
			let dif = Date.parse(latest.timestamp) - Date.parse(response[i].timestamp);
			console.log('dif', dif)
			if (dif > 0) {
				latest = response[i];
			}
		}
	}
});

}

test(3);
