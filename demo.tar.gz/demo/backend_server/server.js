const os = require('os');
const { v4: uuidv4 } = require('uuid');
const express = require('express');
const fetch = require('node-fetch');
const app = express();
const redis = require('redis');
const { promisify } = require('util');
console.log('redis host ', process.env.REDIS_HOST);
console.log('redis port ', process.env.REDIS_PORT);
console.log('pg host ', process.env.PG_HOST);
console.log('pg port ', process.env.PG_PORT);
console.log('pg pass', process.env.PG_PASS);
console.log('pg db', process.env.PG_DB);
const redisClient = redis.createClient({
	host: process.env.REDIS_HOST,
	port: process.env.REDIS_PORT
});
const getAsync = promisify(redisClient.get).bind(redisClient);
const setAsync = promisify(redisClient.set).bind(redisClient);
redisClient.on('error', err => console.log('Redis Client Error', err));
const pg = require('knex')({
  client: 'pg',
  connection: {
    host : process.env.PG_HOST,
    port : process.env.PG_PORT,
    user : process.env.PG_USER,
    password : process.env.PG_PASS,
    database : process.env.PG_DB
  }
});
const TTL = 60000;

app.use(express.json());

// recursively search object for matching key, 
// return corresponding value if found
const extractField = async (targetObject, searchKey) => {
	async function search(data, key) {
		let current = data;
		let next = [];
		let keySet = Object.keys(current)
		for (let i = 0; i < keySet.length; i++) {
			if (keySet[i] === key) { 
				return current[key]; 
			} else if (typeof current[keySet[i]] === 'object' && Array.isArray(current[keySet[i]]) === false) {
				next.push(current[keySet[i]])
			}
		}
		for (let k = 0; k < next.length; k++) {
			let match = await search(next[k], key);
			if (!match.error) {
				return match;
			}
		}
		return {error: 'ERROR: match not found'};
	}
	const timeout = new Promise((resolve, reject) => {
		setTimeout(resolve, 1000, {error: 'ERROR: Object was too large'});
	});
	// the first promise to resolve will be returned,
	// this prevents any search taking longer than the timeout
	return Promise.race([search(targetObject, searchKey), timeout]);
}
const generateId = () => {
	// generate uuid
	return uuidv4();
}
const insertCow = async (data) => {
	try {
		// get collar.id and collar.status
		// check if collar exists, if not, insert it
		let cowNumber = await extractField(data,'cowNumber');
		console.log('cowNumber:', cowNumber)
		let collarId = await extractField(data, 'collarId');
		console.log('collarId:', collarId)
		let collarStatus = 'Healthy';
		let collarExists;
		// if collarId is missing or falsey we insert an empty string in its place
		if (collarId===null || collarId===undefined || collarId==='' || collarId === {} || collarId===[]) {
			collarId = '';
			collarExists = false;
			console.log('collar exists: ', collarExists);
		} else {
		// if collarId is present we check it exists, and if it doesn't, we insert it.
			collarExists = await pg('collars')
				.where({'id': collarId})
				.select();
			console.log('collar exists: ', collarExists);
			if (collarExists.length === 0) {
				await insertCollar(collarId, collarStatus); 
				collarExists = true;

			}

		}
		// check cow number is unique
		let identicalRow = await pg('cows')
			.where({'cownumber': cowNumber})
			.select();
		console.log('identical Row', identicalRow);
		if (identicalRow.length > 0) {
			return {error: 'ERROR: This cow already exists'};
		}
		// generate unique id
		let uuid = generateId();
		console.log("uuid: ", uuid);
		let row = {
			'id': uuid,
			'cownumber': +cowNumber,
			'collar': collarExists ? collarId: null,
		};
		console.log("row: ", row);
		// insert new row into database
		let cowInsertResult = await pg.insert([row]).into('cows');
		console.log('cow insert result ', cowInsertResult);
		// query database for newly inserted row to confirm success
		//
		//
		//let confirmation = await pg('cows')
		//	.where({'id': row['id']})
		//	.select()
		let confirmation = await pg('cows')
			.select('cows.id', 
				'cows.cownumber as cowNumber',
				'cows.collar as collarId', 
				'collars.collarstatus as collarStatus')
			.where({'cows.id': row['id']})
			.join('collars', 'collars.id', 'cows.collar')
			.columns([
			    'cows.id',
			    'cows.cownumber',
			    'cows.collar',
			    'collars.collarstatus'
			    ]);
		// remove duplicate aliases returned by postgres
		console.log('#insertCow() confirmation: ', confirmation);
		let formattedConfirmation = {
			'id': confirmation[0].id,
			'cowNumber': confirmation[0].cowNumber,
			'collarId': confirmation[0].collarId,
			'collarStatus': confirmation[0].collarStatus,
		};
		console.log('confirmation', confirmation);
		console.log('formatted confirmation', formattedConfirmation);
		return formattedConfirmation;
	} catch (err) {
		return {error: err};
	}
}
const insertCollar = async (collarId, collarStatus) => {
	let row = {
		'id': collarId,
		'collarstatus': collarStatus,
	};
	let insertResponse = await pg.insert([row]).into('collars');
	let confirmation = await pg('collars')
		.select('*')
		.where({'id': row['id']})
	console.log('collar inserted ', confirmation);
}
const fetchAllCows = async () => {
	try {
		let allCows = await pg('cows')
			.select('cows.id', 'cows.cownumber as cowNumber','cows.collar as collarId', 'collars.collarstatus as collarStatus')
			.leftJoin('collars', 'collars.id', 'cows.collar')
			.columns([
			    'cows.id',
			    'cows.cownumber',
			    'cows.collar',
			    'collars.collarstatus'
			    ]);
		// remove duplicate aliases returned by postgres
		return allCows.map((x) => {
			return {
				'id': x.id,
				'cowNumber': x.cowNumber,
				'collarId': x.collarId,
				'collarStatus': x.collarStatus,
			}
		});
	} catch (err) {
		return {error: err}

	}
}
const updateCow = async (data) => {
	try {
		let collarId = await extractField(data, 'collarId');
		let cowNumber = await extractField(data,'cowNumber');
		console.log('extracted fields PUT: collarId ' + collarId + ' cowNumber ' + cowNumber);
		let collarExists = await pg('collars')
			.where({'id': collarId})
			.select();
		console.log('PUT collar exists: ', collarExists);
		try {
			// if an empty object is returned 
			if (collarExists.length === 0) {
				await insertCollar(collarId, 'Healthy'); 

			}
		} catch {
			await insertCollar(collarId, 'Healthy'); 
		}
		let row = {
			'collar': collarId,
		};
		console.log('PUT, update row ', row);
		let iferror = await pg('cows')
			.where({'cownumber' : cowNumber})
			//.update(row);
			.update({'collar':collarId}); //TEMP
		console.log('PUT iferror ', iferror);
		console.log('PUT, update executed ');
		//let updatedRow = await pg('cows')
		//	.where({'cownumber': cowNumber})
		//	.select();
		//let confirmation = await pg('cows')
		//	.select('*')
		//	.where({'cownumber': +row['cownumber']})

		let confirmation = await pg('cows')
			.select('cows.id', 
				'cows.cownumber as cowNumber',
				'cows.collar as collarId', 
				'collars.collarstatus as collarStatus')
			.where({'cows.cownumber': +cowNumber})
			.join('collars', 'collars.id', 'cows.collar')
			.columns([
			    'cows.id',
			    'cows.cownumber',
			    'cows.collar',
			    'collars.collarstatus'
			    ]);
		// remove duplicate aliases returned by postgres
		console.log("PUT confirmation ", confirmation);
		return {
			'id': confirmation[0].id,
			'cowNumber': confirmation[0].cowNumber,
			'collarId': confirmation[0].collarId,
			'collarStatus': confirmation[0].collarStatus,
		};
	} catch (err) {
		return {error: err};
	}
}

const getLocationAndStatus = async (collarId) => {
	console.log('GET LOCATION AND STATUS');
	try {
		//check redis for location/status
		//check TTL of cached value
		//let ttl = await sendCommandAsync(['TTL', `${collarId}`]); // returns -2 if key doesn't exist
		let cachedLocationString = await getAsync(`${collarId}`);
		let cachedLocation;
		let ttl = 0;
		if (!(cachedLocation === undefined || cachedLocation === null)){
			cachedLocation = JSON.parse(cachedLocationString);
			console.log('FROM CACHE', cachedLocation)
			console.log('FROM CACHE[3]', cachedLocation[3])
			ttl = (new Date().getTime() - cachedLocation[3])
			console.log('ttl ', ttl);
		}
		if (ttl > 0) {
			//- valid - return location/status
			//let locationAndStatus = await sendCommand(['GET', `${collarId}`]);
			//console.log('parsed value from redis', locationAndStatus)
			return cachedLocation;
			//return [ 'Healthy', 123, 456 ];
		} else {
			console.log('fetching from API');
			await fetch(`https://5d96585ca824b400141d26b2.mockapi.io/halter/device/${collarId}/status`, {
				method: 'GET',
				headers: {
					'Content-Type':'application/json',
					'Cache-Control':'no-cache',
				},
			})
			.then((data) => data.json())
			.then(async (response) => {
				// if multiple, iterate and find latest
				let latest = response; 
				if (Array.isArray(response) && response.length > 1) {
					latest = response[0]; 
					for (let i = 1; i < response.length; i++) {
						console.log('response[i].timestamp', response[i].timestamp);
						let dif = Date.parse(latest.timestamp) - Date.parse(response[i].timestamp);
						console.log('dif', dif)
						if (dif > 0) {
						latest = response[i];
						}
					}
				}
				let restructured = [];
				restructured[0] = !!latest['healthy'] ? 'Healthy' : 'Broken';
				restructured[1] = latest['lat']
				restructured[2] = latest['lng'];
				restructured[3] = new Date().getTime();
				console.log('restructured redis store value', restructured);
				let cacheValue = JSON.stringify(restructured);
				//update redis store
				await setAsync(`${collarId}`, cacheValue);
				//update pg collar.status
				await pg('collars')
					.where({'id' : collarId})
					.update({'collarstatus' : `${restructured[0]}`});
			});
			let locationAndStatus = await getAsync(`${collarId}`);
			console.log('parsed value from redis after insert', JSON.parse(locationAndStatus))
			return JSON.parse(locationAndStatus);
		}
	} catch (err) {
		//if API request fails, set the collar status to 'Broken'
		await pg('collars')
			.where({'id' : collarId})
			.update({'collarstatus' : 'Broken'});
		return {error: err};
	}
};

const packLocationIntoResponse = async (x) => {
	console.log('PACK LOCATION INTO RESPONSE', x);
	let completeResult = x;
	let arr = await getLocationAndStatus(x['collarId'])
	console.log('arr returned from getLocationAndStatus', arr);
	console.log('packed result', completeResult);
	completeResult['collarStatus'] = arr[0];
	completeResult['lastLocation'] = {};
	console.log('packed result', completeResult);
	completeResult['lastLocation']['lat'] = arr[1];
	completeResult['lastLocation']['long'] = arr[2];
	console.log('packed result', completeResult);
	return completeResult;
}

app.get('/', async function(req, res) {
	res.send('OK');
});


app.get('/cows', async function(req, res) {
	try { 
		const postgresResult = await fetchAllCows()
		console.log('#app.get - fetch all cows function returned ', postgresResult);
		if (!postgresResult.error) {
			// map location data onto entities retrieved from database
			let completeResultsArray = await Promise.all(postgresResult.map( async (x) => {
				let y = await packLocationIntoResponse(x);
				return y;
			}));
			res.writeHead(200, { 'Content-Type': 'application/json' });
			res.write(JSON.stringify(completeResultsArray));
			res.end();
		} else {
			res.status(500).json(result);
		}
	} catch (err) {
		console.log('fetchAllCows function threw error', err);
		res.status(500).send(err);
	}
});
app.post('/cows', async function(req,res) {
	const data = req.body;
	console.log('data received', data);
	try { 
		const result = await insertCow(data);
		console.log('result of insertCow: ', result);
		// TODO query for location 
		if (!result.error) {
			let completeResult = await packLocationIntoResponse(result);
			res.writeHead(200, { 'Content-Type': 'application/json' });
			res.write(JSON.stringify(completeResult));
			res.end();
		} else {
			res.status(500).json(result);
		}
	} catch (err) {
		res.status(500).json({"error": `could not insert: ${err}`});
	}
});
app.put('/cows/:id', async function(req,res) {
	try { 
		// pack request body and url parameter into a single object

		let data = {
			id: req.params.id,
			update: req.body
		}
		console.log('received on PUT, ', data);
		const result = await updateCow(data)// pass body and id
		console.log('received as output from updateCow PUT', result);
		
		// TODO query for location 
		if (!result.error) {
			let completeResult = await packLocationIntoResponse(result);
			console.log('PUT result with location', completeResult);
			res.writeHead(200, { 'Content-Type': 'application/json' });
			res.write(JSON.stringify(completeResult));
			res.end();
		} else {
			res.status(500).send(result.error);
		}
	} catch (err) {
		res.status(500).send(err);
	}
});

app.listen(process.env.PORT, '0.0.0.0', function() {
    console.log('Web application is listening on port 5000');
});
